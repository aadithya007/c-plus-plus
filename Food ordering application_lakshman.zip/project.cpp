#include<iostream>
#include<stdio.h>
using namespace std;
int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a=350,b=360,c=380,d=340,e=340,f=400,g=450,h=430,i=420,j=430,k=349,l=399,m=449,n=419,o=429,p=519,q=549,r=599,s=549,t=539,u=159,v=179,w=149,x=169,y=249;
    int y2=249,b1=289,c1=299,d1=319,e1=169,f1=179,g1=189,h1=199,i1=179,j1=219,k1=229,l1=239,m1=239,n1=299,o1=149,p1=189,q1=169,r1=179,s1=199,t1=219;
int sum=0;
int beverages();
int toppings();
int cont();

int go();

int start()
{
    

    // int a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a=350,b=360,c=380,d=340,e=340,f=400,g=450,h=430,i=420,j=430,k=349,l=399,m=449,n=419,o=429,p=519,q=549,r=599,s=549,t=539,u=159,v=179,w=149,x=169,y=249,z=129;
    // int y2=249,b1=289,c1=299,d1=319,e1=169,f1=179,g1=189,h1=199,i1=179,j1=219,k1=229,l1=239,m1=239,n1=299,o1=149,p1=189,q1=169,r1=179,s1=199,t1=219;
    
    cout<<"1.BIRIYANI\n2.PIZZA\n3.BURGER\n4.MOMOS\n5.ICE CREAM\n6.BEVERAGES"<<endl;
    cout<<"please select your choice:";
    cin>>a1;
    switch(a1)
{
case 1:
    cout<<"BIRIYANI"<<endl;
    {
        cout<<"please select your choice"<<endl;
        cout<<"1.VEGETARIAN\n2.NON VEGETARIAN"<<endl;
        cin>>a2;
        switch(a2)
    {
        case 1:
        cout<<"VEGETARIAN"<<endl;
            cout<<"1.MINTY PANNER BIRIYANI--"<<endl;
            cout<<"2.LAYERED BREAD KOFTA BIRIYANI--"<<endl;
            cout<<"3.ALMOND BIRIYANI--"<<endl;
            cout<<"4.KABULI MUSHROOM BIRIYANI--"<<endl;
            cout<<"5.LAJJATADAR HANDI BIRIYANI--"<<endl;
            cout<<"enter your choice:";
            cin>>a3;
            switch(a3)
            {
                case 1:
                    cout<<"MINTY PANNER BIRIYANI--"<<a<<endl;
                    sum+=a;
                    break;
                case 2:
                    cout<<"LAYERED BREAD KOFTA BIRIYANI--"<<b<<endl;
                    sum+=b;
                    break;
                case 3:
                    cout<<"ALMOND BIRIYANI--"<<c<<endl;
                    sum+=c;
                    break;
                case 4:
                    cout<<"KABULI MUSHROOM BIRIYANI--"<<d<<endl;
                    sum+=d;
                break;
                case 5:
                   cout<<"LAJJATADAR HANDI BIRIYANI--"<<e<<endl;
                   sum+=e;
                break;
            }
            cont();
            break;
            
            
               
                
            
        
        case 2:
        cout<<"NON-VEGETARIAN"<<endl;
            cout<<"1.MALABAR CHICKEN BIRIYANI"<<endl;
            cout<<"2.THALASSERY MUTTON BIRIYANI"<<endl;
            cout<<"3.BANGLADESHI PRAWN BIRIYANI"<<endl;
            cout<<"4.CHETTINAD FISH BIRIYANI"<<endl;
            cout<<"5.CALICUT DUM BIRIYANI"<<endl;
            cout<<"enter your choice:";
            cin>>a4;
        switch(a4)
        {
        case 1:
            cout<<"MALABAR CHICKEN BIRIYANI--"<<f<<endl;
            sum+=f;
            break;
        case 2:
            cout<<"THALASSERY MUTTON BIRIYANI--"<<g<<endl;
            sum+=g;
             break;
        case 3:
            cout<<"BANGLADESHI PRAWN BIRIYANI--"<<h<<endl;
            sum+=h;
        break;
        case 4:
            cout<<"CHETTINAD FISH BIRIYANI--"<<i<<endl;
            sum+=i;
       break;
        case 5:
            cout<<"CALICUT DUM BIRIYANI--"<<j<<endl;
            sum+=j;
       break;
        }
        
            
    }
    
        
    }
    cont();
    break;


case 2:
        cout<<"PIZZA"<<endl;
        {
        cout<<"please select your choice"<<endl;
         cout<<"1.VEGETARIAN\n2.NON VEGETARIAN"<<endl;
        cin>>a5;
        switch(a5)
        {
        case 1:
        cout<<"VEGETARIAN"<<endl;
            cout<<"1.BLAZING ONION AND PARIKA--"<<endl;
            cout<<"2.FARM HOUSE--"<<endl;
            cout<<"3.PEPPY PANNER--"<<endl;
            cout<<"4.DULUXE VEGGIE--"<<endl;
            cout<<"5.FIERY JALAPENO AND PAPRIKA--"<<endl;
            cout<<"enter your choice:";
            cin>>a6;
            switch(a6)
            {
                case 1:
                    cout<<"BLAZING ONION AND PARIKA PIZZA--"<<k<<endl;
                    sum+=k;
                break;
                case 2:
                    cout<<"FARM HOUSE PIZZA--"<<l<<endl;
                    sum+=l;
                break;
                case 3:
                    cout<<"PEPPY PANNER PIZZA--"<<m<<endl;
                    sum+=m;

               break;
                case 4:
                    cout<<"DULUXE VEGGIE PIZZA--"<<n<<endl;
                    sum+=n;
              break;
                case 5:
                    cout<<"FIERY JALAPENO AND PAPRIKA PIZZA--"<<o<<endl;
                    sum+=o;
           break;
            }
            cont();
            break;
            case 2:
            cout<<"NON-VEGETARIAN"<<endl;
            cout<<"1.FIERY SAUSAGE AND PAPRIKA PIZZA"<<endl;
            cout<<"2.PEPPER BARBECUE CHICKEN PIZZA"<<endl;
            cout<<"3.CHICKEN DOMINATOR PIZZA"<<endl;
            cout<<"4.INDO FUSION CHICKEN PIZZA"<<endl;
            cout<<"5.CHICKEN PEPPERONI PIZZA"<<endl;
            cout<<"enter your choice:";
            cin>>a7;
         switch(a7)
            {
            case 1:
            cout<<"FIERY SAUSAGE AND PAPRIKA PIZZA--"<<p<<endl;
            sum+=p;
            break;
             case 2:
            cout<<"PEPPER BARBECUE CHICKEN PIZZA--"<<q<<endl;
            sum+=q;
        break;
            case 3:
            cout<<"CHICKEN DOMINATOR PIZZA--"<<r<<endl;
            sum+=r;
          break;
            case 4:
            cout<<"INDO FUSION CHICKEN PIZZA--"<<s<<endl;
            sum+=s;
          break;
             case 5:
            cout<<"CHICKEN PEPPERONI PIZZA--"<<t<<endl;
            sum+=t;
          break;
        }
        cont();
        break;
            
        }
    
        
    }
   

case 3:
    cout<<"BURGER"<<endl;
    {
        
        cout<<"please select your choice"<<endl;
         cout<<"1.VEGETARIAN\n2.NON VEGETARIAN"<<endl;
        cin>>a8;
        switch(a8)
    {
        case 1:
        cout<<"VEGETARIAN"<<endl;
      
            cout<<"1.BBQ BEEMER BURGER"<<endl;
            cout<<"2.SIRRACHA CHEESE BOOM BURGER"<<endl;
            cout<<"3.MUSHROOM CHEESE BURGER"<<endl;
            cout<<"4.PANNER MAKHANI BURGER"<<endl;
            cout<<"5.CRISPY VEG BURGER-TANDOORI"<<endl;
            cout<<"enter your choice:";
            cin>>a9;
            switch(a9)
        {
                case 1:
                    cout<<"BBQ BEEMER BURGER--"<<u<<endl;
                    sum+=u;
                break;
                case 2:
                    cout<<"SIRRACHA CHEESE BOOM BURGER--"<<v<<endl;
                    sum+=v;

           break;
                case 3:
                    cout<<"MUSHROOM CHEESE BURGER--"<<w<<endl;
                    sum+=w;

          break;
                case 4:
                    cout<<"PANNER MAKHANI BURGER--"<<x<<endl;
                    sum+=x;

         break;
                case 5:
                    cout<<"CRISPY VEG BURGER-TANDOORI--"<<y<<endl;
                     sum+=y;
        break;
        }
        cont();
        break;
case 2:
        cout<<"NON-VEGETARIAN"<<endl;
            cout<<"1.CRISPY CHICKEN BURGER-TANDOORI"<<endl;
            cout<<"2.MEXICAN CHICKEN BURGER"<<endl;
            cout<<"3.FULLY LOADED CAJUN CHICKEN BURGER"<<endl;
            cout<<"4.SRIRACHA-GLAZED CHICKEN BURGER AND PICKLED CABBAGE"<<endl;
            cout<<"5.KOREAN FRIED CHICKEN WITH HONEY TOSSED ONIONS"<<endl;
            cout<<"enter your choice:";
            cin>>a10;
        switch(a10)
        {
        case 1:
            cout<<"CRISPY CHICKEN BURGER-TANDOORI--"<<y2<<endl;
            sum+=y2;
  break;
        case 2:
            cout<<"MEXICAN CHICKEN BURGER--"<<b1<<endl;
            sum+=b1;
      break;
        case 3:
            cout<<"FULLY LOADED CAJUN CHICKEN BURGER--"<<c1<<endl;
             sum+=c1;
     break;
        case 4:
            cout<<"SRIRACHA-GLAZED CHICKEN BURGER AND PICKLED CABBAGE--"<<d1<<endl;
            sum+=d1;
break;
        case 5:
            cout<<"KOREAN FRIED CHICKEN WITH HONEY TOSSED ONIONS--"<<e1<<endl;
            sum+=e1;
break;
        }
        
            
        }
    
        
    }
    cont();
    break;

    case 4:
    cout<<"MOMOS"<<endl;
     {
        cout<<"please select your choice"<<endl;
         cout<<"1.VEGETARIAN\n2.NON VEGETARIAN"<<endl;
        cin>>a11;
        switch(a11)
    {
        case 1:
        cout<<"VEGETARIAN"<<endl;
    
            cout<<"1.ITALIAN BBQ PANNER MOMOS---STEAMED/FRIED--"<<endl;
            cout<<"2.THAI MUSHROOM CHEESE MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"3.CHINESE TOFFU MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"4.FIERY FRIED VEGGIES MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"5.INDO FRENCH MARINA MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"enter your choice:";
            cin>>a12;
            switch(a12)
        {
                case 1:
                    cout<<"ITALIAN BBQ PANNER MOMOS---STEAMED/FRIED--"<<f1<<endl;
                    sum+=f1;
              break;
                case 2:
                    cout<<"THAI MUSHROOM CHEESE MOMOS----STEAMED/FRIED--"<<g1<<endl;
                    sum+=g1;
                break;
                case 3:
                    cout<<"CHINESE TOFFU MOMOS----STEAMED/FRIED--"<<h1<<endl;
                    sum+=h1;
              break;
                case 4:
                    cout<<"FIERY FRIED VEGGIES MOMOS----STEAMED/FRIED--"<<i1<<endl;
                    sum+=i1;
              break;
                case 5:
                    cout<<"INDO FRENCH MARINA MOMOS----STEAMED/FRIED--"<<j1<<endl;
                    sum+=j1;
         break;
        }
        cont();
        break;
case 2:
        cout<<"NON-VEGETARIAN"<<endl;
            cout<<"1.AFGAHNI CHICKEN MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"2.MEXICAN CHICKEN MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"3.NON VEG MIXED FULLY LOADED MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"4.FIERY FRIED SPICED CHICKEN MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"5.INDO THAI FUSED MOMOS----STEAMED/FRIED--"<<endl;
            cout<<"enter your choice:";
            cin>>a13;
        switch(a13)
        {
        case 1:
            cout<<"AFGAHNI CHICKEN MOMOS----STEAMED/FRIED--"<<k1<<endl;
            sum+=k1;
  break;
        case 2:
            cout<<"MEXICAN CHICKEN MOMOS----STEAMED/FRIED--"<<l1<<endl;
            sum+=l1;
   break;
        case 3:
            cout<<"NON VEG MIXED FULLY LOADED MOMOS----STEAMED/FRIED--"<<m1<<endl;
            sum+=m1;
   break;
        case 4:
            cout<<"FIERY FRIED SPICED CHICKEN MOMOS----STEAMED/FRIED--"<<n1<<endl;
            sum+=n1;
   break;
        case 5:
            cout<<"INDO THAI FUSED MOMOS----STEAMED/FRIED--"<<o1<<endl;
            sum+=o1;
   break;
        }
        break;
        
            
        }
    
        
    }
    
    break;
    case 5:
    cout<<"ICE CREAM"<<endl;
    {
        {   cout<<"1.CHERRY GARCIA"<<endl;
            cout<<"2.MOCHA"<<endl;
            cout<<"3.MONATO STRAWBERRY"<<endl;
            cout<<"4.CHOCOCHIP DUNKIES"<<endl;
            cout<<"5.CRUNCHY BREAK BLACKCURRANT"<<endl;
            cout<<"enter your choice:";
            cin>>a14;
            switch(a14)
        {
                case 1:
                cout<<"CHERRY GARCIA--"<<p1<<endl;
                sum+=p1;
                                break;
                case 2:
                    cout<<"MOCHA--"<<q1<<endl;
                    sum+=q1;
                break;
                case 3:
                    cout<<"MONATO STRAWBERRY--"<<r1<<endl;
                    sum+=r1;
                    break;
                
                case 4:
                    cout<<"CHOCOCHIP DUNKIES--"<<s1<<endl;
                    sum+=s1;
                break;
                case 5:
                    cout<<"CRUNCHY BREAK BLACKCURRANT--"<<t1<<endl;
                    sum+=t1;
                break;
        }
        

    }
    }
  toppings();
  break;
case 6:{
    beverages();

}
}
}


int beverages();
int cont()
{
    char z1,z2,z3,z4,z5;
     cout<<"Do u wish to continue----Yes(Y)or No(N)";
                cin>>z1;
                if(z1=='y')
                {
                  cout<<"Thank you!!! continue choosing your meal...."<<endl;
                 start();
                }
                  else if(z1=='n')               
                  {
                    beverages();
                    
                    
                    
                  }
                  

}
int conti()
{
    {
                cout<<"Thank you!!! continue choosing your meal...."<<endl;
                 start();
                }
                  

}

int main()
{   
    char name[50];
    cout<<"                       welcome!!!\n";
    cout<<"                      GRAND FUSION\n";
    cout<<"                            -Food court,brookfields mall,coimbatore\n";
    cout<<"                             ph:0422-256897\n";
    cout<<"Your good name please:";
    cin>>name;
    cout<<"hello "<<name<<"\n"<<"thank you for choosing grand fusion!!\n"<<endl;
    start();
}
int beverages();
int toppings()
{
    char b2;
    int b3,b4=30,b5=40,b6=40,b7=25,b8=25,b9=35,b10=40,b11=45,b12=45,b13=35;


cout<<"Do you wish to add toppings and make your icecream even more tastier??Yes(Y)orNo(N):)"<<endl;
cin>>b2;
if(b2=='y')
{ cout<<"1.CHOCO CHIPS---milk chocolate"<<endl;
cout<<"2.CHOCO CHIPS---dark chocolate"<<endl;
cout<<"3.CHOCO CHIPS---white chocolate"<<endl;
cout<<"4.TWISTERS"<<endl;
cout<<"5.GEMS"<<endl;
cout<<"6.KITKAT"<<endl;
cout<<"7.CHERRIES"<<endl;
cout<<"8.CRUNCHY CURRENTS"<<endl;
cout<<"9.RAINBOW SPRINKLERS"<<endl;
 cout<<"10.CHOCOLATE SPRINKLERS"<<endl;
 cout<<"Make your choice and make your ice cream tastier:";
 cin>>b3;
    switch(b3)
    {
        case 1:
        cout<<"CHOCO CHIPS---milk chocolate--"<<b4<<endl;
        sum+=b4;
        break;
 
        case 2:
        cout<<"CHOCO CHIPS---dark chocolate--"<<b5<<endl;
        sum+=b5;
        break;
        case 3:
        cout<<"CHOCO CHIPS---white chocolate--"<<b6<<endl;
        sum+=b6;
        break;
        case 4:
        cout<<"TWISTERS--"<<b7<<endl;
        sum+=b7;
        break;
        case 5:
        cout<<"GEMS--"<<b8<<endl;
        sum+=b8;
        break;
        case 6:
        cout<<"KITKAT--"<<b9<<endl;
        sum+=b9;
        break;
        case 7:
        cout<<"CHERRIES--"<<b10<<endl;
        sum+=b10;
        break;
        case 8:
        cout<<"CRUNCHY CURRENTS--"<<b11<<endl;
        sum+=b11;
        break;
        case 9:
        cout<<"RAINBOW SPRINKLERS--"<<b12<<endl;
        sum+=b12;
        break;
        case 10:
        cout<<"CHOCOLATE SPRINKLERS--"<<b13<<endl;
        sum+=b13;
        break;
    }
    cont();
}
else if(b2=='n')
{
    cout<<"OMG!!!YOU MISSED YOUR CHANCE TO MAKE YOUR TREAT MORE SPECIAL!!! "<<endl;
    cont();
}

}


int beverages()
{
  
    char c2,e4;
    int c3=149,c4=129,c5=139,c6=129,c7=129,c8=125,c9=149,c10=140,c11=40,c12=60;


cout<<"Would you like to add a drink to your meal???--yes(Y)or NO(N)"<<endl;
cin>>c2;
if(c2=='y')
{
   cout<<"enter your choice and enjoy your meal with a drink:)"<<endl;
cout<<"1.LEMON MOJITO"<<endl;
cout<<"2.GRAND FUSION SPL MILKSHAKE"<<endl;
cout<<"3.THAI FUSION FALOODA"<<endl;
cout<<"4.MORINTO MOCKTAIL"<<endl;
cout<<"5.APPLE MOJITO"<<endl;
cout<<"6.KOREA CHOCO DELIGHT"<<endl;
cout<<"7.PET BOTTLES--SPRITE/COKE/7UP/MIRANDA/FANTA"<<endl;
cout<<"8.WATER BOTTLE"<<endl;
    cin>>c3;
    switch(c3)
    {
        case 1:
        cout<<"LEMON MOJITO--"<<c4<<endl;
        sum+=c4;
        break;
        case 2:
        cout<<"GRAND FUSION SPL MILKSHAKE--"<<c5<<endl;
        sum+=c5;
        break;
        case 3:
        cout<<"THAI FUSION FALOODA--"<<c6<<endl;
        sum+=c6;
        break;
        case 4:
        cout<<"MORINTO MOCKTAIL--"<<c7<<endl;
        sum+=c7;
        break;
        case 5:
        cout<<"APPLE MOJITO--"<<c8<<endl;
        sum+=c8;
        break;
        case 6:
        cout<<"KOREA CHOCO DELIGHT--"<<c9<<endl;
        sum+=c9;
        break;
        case 7:
        cout<<"PET BOTTLES--SPRITE/COKE/7UP/MIRANDA/FANTA--"<<c10<<endl;
        sum+=c10;
        break;
        case 8:
        cout<<"WATER BOTTLE--"<<c11<<endl;
        sum+=c11;
        break;
       
    }
    go();
}
else if(c2=='n')
{
  go(); 
}
}
int conti();
int go()
{
    char e4;
   
cout<<"Proceed to place your order Yes(Y)orNo(N)???";
 cin>>e4;
    if(e4=='y')
    {
    cout<<"                      THANK YOU!!!PLEASE VISIT AGAIN :)"<<endl;
    cout<<"                 OUR DELIVERY PARTNER WILL REACH AT YOUR DOOR STEP SOON!!!"<<endl;
    cout<<"Mode of payment:CASH ON DELIVERY(COD)"<<endl;
    cout<<"Amount to be paid:Rs."<<sum<<endl;
    cout<<"----------------------------------------------------------------------------------------------";
    cout<<"                              GRAND FUSION\n";
    cout<<"                    -Food court,brookfields mall,coimbatore\n";
    cout<<"                         ph:0422-256897\n";
    }
    else if(e4=='n')
   {
    conti();
   }
}

